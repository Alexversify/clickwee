Catppuccin Green cursor for Windows

Design: Catppuccin
Source: https://github.com/catppuccin/cursors
License: GPL-2.0 (https://www.gnu.org/licenses/old-licenses/gpl-2.0.html)

Converted to Windows .cur/.ani by Clickwee (https://clickwee.com).
The conversion tool is at https://github.com/Alexversify/clickwee/tree/main/tools
