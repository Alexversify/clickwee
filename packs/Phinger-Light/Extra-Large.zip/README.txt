Phinger Light cursor for Windows

Design: Philipp Schaffrath
Source: https://github.com/phisch/phinger-cursors
License: CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/)

Converted to Windows .cur/.ani by Clickwee (https://clickwee.com).
The conversion tool is at https://github.com/Alexversify/clickwee/tree/main/tools
