Future cursor for Windows

Design: yeyushengfan258
Source: https://github.com/yeyushengfan258/Future-cursors
License: GPL-3.0 (https://www.gnu.org/licenses/gpl-3.0.html)

Converted to Windows .cur/.ani by Clickwee (https://clickwee.com).
The conversion tool is at https://github.com/Alexversify/clickwee/tree/main/tools
