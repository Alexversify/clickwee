Fuchsia Bounce cursor for Windows

Design: ful1e5, Clickwee
Source: https://github.com/ful1e5/fuchsia-cursor
License: GPL-3.0 (https://www.gnu.org/licenses/gpl-3.0.html)

Converted to Windows .cur/.ani by Clickwee (https://clickwee.com).
The conversion tool is at https://github.com/Alexversify/clickwee/tree/main/tools
